def main():
    print("hello from app")

def helper():
    return 42
staged edit marker STAGED_FEATURE_FLAG
